<?php

/** Configuration Variables **/

define ('DEVELOPMENT_ENVIRONMENT',true);

define('DB_NAME', 'lab8.1');
define('DB_USER', 'thaian229');
define('DB_PASSWORD', '22114455');
define('DB_HOST', 'localhost');
